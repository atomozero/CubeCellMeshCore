# CubeCellMeshCore v0.5.0

MeshCore-compatible repeater firmware for Heltec CubeCell HTCC-AB01.

## What's New in v0.5.0

- **Store-and-Forward Mailbox** - Messages for offline nodes are stored and automatically re-delivered when the node comes back online. 2 persistent EEPROM slots + 4 volatile RAM slots = 6 messages max.
- **Mesh Health Monitor** - Automatic alerts when nodes go offline (>30 min). Per-node SNR tracking detects link degradation.
- **Full Remote Configuration** - All 50+ CLI commands available remotely via the MeshCore app's encrypted channel. No USB cable needed to manage a deployed repeater.
- **Session Security** - Idle sessions now expire after 1 hour.
- **Major Code Optimization** - Merged duplicate CLI handlers and eliminated float parsing. Saved 12.9 KB Flash (was 98.2%, now 91.0%).

## Features

- MeshCore protocol compatible (Android/iOS apps)
- Ed25519 identity and signatures
- ADVERT broadcasting with time synchronization
- SNR-based CSMA/CA packet forwarding
- Store-and-forward mailbox for offline nodes
- Mesh health monitoring with automatic alerts
- Full remote configuration via encrypted mesh CLI
- Daily status reports sent to admin
- Deep sleep support (~20 uA)
- Battery and temperature telemetry
- Neighbour tracking (direct 0-hop repeaters)
- Rate limiting (login, request, forward)
- Persistent lifetime statistics (EEPROM)

## Hardware

- **Board**: Heltec CubeCell HTCC-AB01
- **MCU**: ASR6501 (ARM Cortex-M0+ @ 48 MHz + SX1262)
- **Flash**: 128 KB (91.0% used, ~12 KB free)
- **RAM**: 16 KB (47.9% used)
- **Radio**: SX1262 LoRa (EU868: 869.618 MHz, BW 62.5 kHz, SF8, CR 4/8)

## Files Included

| File | Description |
|------|-------------|
| `firmware.cyacd` | Flash image for CubeCellTool (Windows) |
| `firmware.hex` | Intel HEX format |
| `INSTALL.md` | Installation and first boot guide |
| `COMMANDS.md` | Full command reference (50+ commands) |
| `README.md` | This file |
| `README_VEN.md` | Sta pàgina qua in venessian |

## Quick Start

1. Flash `firmware.cyacd` via CubeCellTool or PlatformIO
2. Connect serial at 115200 baud
3. Set passwords: `passwd admin <pwd>` then `save`
4. Set node name: `name MyRepeater` then `save`
5. The node will start broadcasting ADVERTs and forwarding packets

See `INSTALL.md` for detailed instructions.

## Links

- Source: https://github.com/atomozero/CubeCellMeshCore
- MeshCore: https://github.com/meshcore-dev/MeshCore
